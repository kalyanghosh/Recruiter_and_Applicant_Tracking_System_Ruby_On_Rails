class ExceptionController < ApplicationController

  def index

  end

end
