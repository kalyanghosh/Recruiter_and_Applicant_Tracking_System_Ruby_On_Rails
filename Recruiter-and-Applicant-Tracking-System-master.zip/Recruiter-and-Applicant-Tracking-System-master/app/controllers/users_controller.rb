class UsersController < ApplicationController
  before_action :set_user, only: [:show, :edit, :update, :destroy]

  # GET /users
  # GET /users.json
  def index
    @users = User.all
  end

  # GET /users/1
  # GET /users/1.json
  def show
    @user = User.find(params[:id])
  end

  # GET /users/new
  def new
    @user = User.new
  end

  # GET /users/1/edit
  def edit
    @user = User.find(params[:id])
  end

  # POST /users
  # POST /users.json
  def create
    @user = User.new(user_params)
    @current_user = current_user

    respond_to do |format|
      if @user.save
        if @current_user.nil?
          if @user.role == 'Recruiter'
            log_in @user
            format.html { redirect_to recruiter_path }
            format.json { render :show, status: :created, location: recruiter_path }
          elsif @user.role == 'Applicant'
            log_in @user
            format.html { redirect_to job_seeker_path }
            format.json { render :show, status: :created, location: job_seeker_path }
          end
        else
          if @user.role == 'Recruiter' && @current_user.role == 'Admin'
            format.html { redirect_to admin_path }
            format.json { render :show, status: :created, location: admin_path }
          elsif @user.role == 'Applicant' && @current_user.role == 'Admin'
            format.html { redirect_to admin_path }
            format.json { render :show, status: :created, location: admin_path }
          end
        end
      else
        format.html { render :new }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  def admin; end

  def recruiter; end

  def job_seeker; end

  # PATCH/PUT /users/1
  # PATCH/PUT /users/1.json
  def update
    respond_to do |format|
      if @user.update(user_update_params)
        format.html { redirect_to @user }
        format.json { render :show, status: :ok, location: @user }
      else
        format.html { render :edit }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /users/1
  # DELETE /users/1.json
  def destroy
    @user.destroy
    respond_to do |format|
      format.html { redirect_to users_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
  def set_user
    @user = User.find(params[:id])
  end

    # Never trust parameters from the scary internet, only allow the white list through.
  def user_params
    params.require(:user).permit(:email, :name, :password, :password_confirmation, :phone_number, :role)
  end

  def user_update_params
    params.require(:user).permit(:email, :name, :password, :password_confirmation, :phone_number, :role, :company_id)
  end
end
