class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
  include SessionsHelper

  rescue_from Exception do |exception|
    flash[:error] = exception.message
    redirect_to :controller => 'exception' , :action => 'index'
  end

end
