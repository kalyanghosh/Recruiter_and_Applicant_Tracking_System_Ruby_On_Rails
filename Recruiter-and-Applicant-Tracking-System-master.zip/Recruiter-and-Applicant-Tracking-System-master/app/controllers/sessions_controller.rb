class SessionsController < ApplicationController
  def new
  end

  def create
    @user = User.find_by(email: params[:session][:email].downcase)
    if @user && @user.authenticate(params[:session][:password])
      log_in @user
      if @user.role == 'Applicant'
        redirect_to job_seeker_path
      elsif @user.role == 'Recruiter'
        redirect_to recruiter_path
      elsif @user.role == 'Admin'
        redirect_to admin_path
      else
        flash.now[:danger] = 'User is not assigned to a role'
        render 'new'
      end
    else
      flash.now[:danger] = 'Invalid email/password combination'
      render 'new'
    end
  end

  def destroy
    log_out
    redirect_to root_url
  end
end
