module ExceptionHelper
end
