class Company < ApplicationRecord
  has_many :jobs, :dependent => :delete_all
  has_many :applications

  validates :Company_id, presence: true
  validates :Name, presence: true
  validates :Website, presence: true, format: { with:  /((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/, message: "use www in front of url" }
  validates :Headquarters, presence: true
  validates_inclusion_of :Size, in: %w{0-1000 1000-2000 2000-3000 3000-4000 4000-5000 5000+}, :presence => true
  validates :Founded, presence: true, format: { with: /(\d){4}/, message: "Enter a valid Year"}
  validates :Industry, presence: true
  validates :Revenue, presence: true
  validates :Synopsis, presence: true
end
