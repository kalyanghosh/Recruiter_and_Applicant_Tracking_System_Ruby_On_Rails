require 'carrierwave'
require 'carrierwave/orm/activerecord'

class Application < ApplicationRecord
  belongs_to :company

  validates :application_id, presence: true
  validates :Linkedin_url, format: {with: //, message: "Enter a valid Linkedin Url(start with HTTPS ot HTTP)"}
  validates :Portfolio_url, format: { with:  /((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/, message: "use www in front of url" }
  validates :Additional_information, presence: false
  validates_inclusion_of :Gender, in: %w{Male Female Other}, presence: true
  validates_inclusion_of :Race, in: %w{American\ Indian Alaskan\ Native Asian African\ American Native\ Hawaiian White}, presence: true
  validates_inclusion_of :Veteran_status, in: %w{Yes No}, presence: true
  validates_inclusion_of :Disability_status, in: %w{Yes No}, presence: true
  # mount_uploader :Resume, ResumeUploader

end
