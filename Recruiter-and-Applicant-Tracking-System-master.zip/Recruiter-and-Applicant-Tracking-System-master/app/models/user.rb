class User < ApplicationRecord
  ROLES = %w[Recruiter Applicant].freeze
  before_save { self.email = email.downcase }
  validates :name, presence: true
  validates :email, presence: true, format: { with: /\A[\w+\-.]+@[a-z\d\-.]+\.[a-z]+\z/i, message: 'Invalid email' },
                    uniqueness: { case_sensitive: false }
  has_secure_password
  validates :phone_number, :presence => true, format: { with: /[0-9]{10}/ , message: "Enter a 10 digit valid number" }
end
