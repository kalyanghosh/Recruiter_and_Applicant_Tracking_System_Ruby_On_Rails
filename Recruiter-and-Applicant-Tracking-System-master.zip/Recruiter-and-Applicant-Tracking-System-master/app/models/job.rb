class Job < ApplicationRecord
  belongs_to :company

  validates :Job_id, presence: true
  validates :company, presence: true
  validates :Job_description, presence: true
  validates :Employment_type, presence: true
  validates :Responsibilities, presence: true
  validates :Requirements, presence: true
end
