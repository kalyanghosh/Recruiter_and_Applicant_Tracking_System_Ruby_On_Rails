Rails.application.routes.draw do
  root 'sessions#new'
  resources :homepages
  resources :users
  resources :applications
  resources :jobs
  resources :companies

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  #
  get '/exception' ,to: 'exception#index'
  get '/login', to: 'sessions#new'
  get '/signup', to: 'users#new'
  post '/login', to: 'sessions#create'
  delete '/logout', to: 'sessions#destroy'
  get '/admin', to: 'users#admin'
  get '/recruiter', to: 'users#recruiter'
  get '/job_seeker', to: 'users#job_seeker'
  post '/filtered_jobs', to: 'jobs#filtered_edit'
end
