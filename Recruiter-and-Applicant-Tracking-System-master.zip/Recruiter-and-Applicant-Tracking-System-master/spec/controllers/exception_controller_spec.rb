require 'rails_helper'

RSpec.describe ExceptionController, type: :controller do

end
