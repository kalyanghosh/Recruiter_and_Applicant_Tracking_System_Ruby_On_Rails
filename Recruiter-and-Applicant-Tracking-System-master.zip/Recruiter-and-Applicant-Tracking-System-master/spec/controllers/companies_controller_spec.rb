require 'rails_helper'

RSpec.describe CompaniesController do

  it 'should get index' do
    get :index
    expect(response).to have_http_status('200')
    expect(assigns(:companies)).to_not be_nil
  end
end
