require 'rails_helper'

RSpec.describe Company do
  fixtures :companies
  subject { Company.new }

  it 'is a valid Company' do
    @company = companies(:Amazon)
    expect(@company).to be_valid
  end

  it 'is not a valid Company with a missing Company id' do
    @company = companies(:Amazon)
    expect(subject).not_to be_valid
  end

  it 'is not a valid Company with a missing Name' do
    @company = companies(:Amazon)
    subject.Company_id = @company.Company_id
    expect(subject.Company_id).to eq(@company.Company_id)
    expect(subject).to_not be_valid
  end

  it 'is not a valid Company with a missing Website' do
    @company = companies(:Amazon)
    subject.Company_id = @company.Company_id
    subject.Name = @company.Name
    expect(subject.Company_id).to eq(@company.Company_id)
    expect(subject.Name).to eq(@company.Name)
    expect(subject).to_not be_valid
  end

  it 'is not a valid Company with a Website that is not formatted correctly' do
    @company = companies(:Amazon)
    subject.Company_id = @company.Company_id
    subject.Name = @company.Name
    subject.Website = 'amazon.com'
    expect(subject.Company_id).to eq(@company.Company_id)
    expect(subject.Name).to eq(@company.Name)
    expect(subject.Website).to_not eq(@company.Website)
    expect(subject).to_not be_valid
  end

  it 'is not a valid Company with a missing Headquarters' do
    @company = companies(:Amazon)
    subject.Company_id = @company.Company_id
    subject.Name = @company.Name
    subject.Website = @company.Website
    expect(subject.Company_id).to eq(@company.Company_id)
    expect(subject.Name).to eq(@company.Name)
    expect(subject.Website).to eq(@company.Website)
    expect(subject).to_not be_valid
  end

  it 'is not a valid Company with a missing Size' do
    @company = companies(:Amazon)
    subject.Company_id = @company.Company_id
    subject.Name = @company.Name
    subject.Website = @company.Website
    subject.Headquarters = @company.Headquarters
    expect(subject.Company_id).to eq(@company.Company_id)
    expect(subject.Name).to eq(@company.Name)
    expect(subject.Website).to eq(@company.Website)
    expect(subject.Headquarters).to eq(@company.Headquarters)
    expect(subject).to_not be_valid
  end

  it 'is not a valid Company with a Size that is not formatted correctly' do
    @company = companies(:Amazon)
    subject.Company_id = @company.Company_id
    subject.Name = @company.Name
    subject.Website = @company.Website
    subject.Headquarters = @company.Headquarters
    subject.Size = '100'
    expect(subject.Company_id).to eq(@company.Company_id)
    expect(subject.Name).to eq(@company.Name)
    expect(subject.Website).to eq(@company.Website)
    expect(subject.Headquarters).to eq(@company.Headquarters)
    expect(subject.Size).to_not eq(@company.Size)
    expect(subject).to_not be_valid
  end

  it 'is not a valid Company with a missing Location' do
    @company = companies(:Amazon)
    subject.Company_id = @company.Company_id
    subject.Name = @company.Name
    subject.Website = @company.Website
    subject.Headquarters = @company.Headquarters
    subject.Size = @company.Size
    expect(subject.Company_id).to eq(@company.Company_id)
    expect(subject.Name).to eq(@company.Name)
    expect(subject.Website).to eq(@company.Website)
    expect(subject.Headquarters).to eq(@company.Headquarters)
    expect(subject.Size).to eq(@company.Size)
    expect(subject).to_not be_valid
  end

  it 'is not a valid Company with a missing Revenue' do
    @company = companies(:Amazon)
    subject.Company_id = @company.Company_id
    subject.Name = @company.Name
    subject.Website = @company.Website
    subject.Headquarters = @company.Headquarters
    subject.Size = @company.Size
    subject.Founded = @company.Founded
    expect(subject.Company_id).to eq(@company.Company_id)
    expect(subject.Name).to eq(@company.Name)
    expect(subject.Website).to eq(@company.Website)
    expect(subject.Headquarters).to eq(@company.Headquarters)
    expect(subject.Size).to eq(@company.Size)
    expect(subject.Founded).to eq(@company.Founded)
    expect(subject).to_not be_valid
  end

  it 'is not a valid Company with a missing Synopsis' do
    @company = companies(:Amazon)
    subject.Company_id = @company.Company_id
    subject.Name = @company.Name
    subject.Website = @company.Website
    subject.Headquarters = @company.Headquarters
    subject.Size = @company.Size
    subject.Founded = @company.Founded
    subject.Revenue = @company.Revenue
    expect(subject.Company_id).to eq(@company.Company_id)
    expect(subject.Name).to eq(@company.Name)
    expect(subject.Website).to eq(@company.Website)
    expect(subject.Headquarters).to eq(@company.Headquarters)
    expect(subject.Size).to eq(@company.Size)
    expect(subject.Founded).to eq(@company.Founded)
    expect(subject.Revenue).to eq(@company.Revenue)
    expect(subject).to_not be_valid
  end

  it 'is associated with many jobs' do
    t = Company.reflect_on_association(:jobs)
    expect(t.macro).to eq(:has_many)
  end
end
