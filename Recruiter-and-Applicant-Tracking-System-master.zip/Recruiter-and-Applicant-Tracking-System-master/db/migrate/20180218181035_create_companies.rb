class CreateCompanies < ActiveRecord::Migration[5.2]
  def change
    create_table :companies do |t|
      t.string :Company_id
      t.string :Name
      t.string :Website
      t.string :Headquarters
      t.string :Size
      t.string :Founded
      t.string :Industry
      t.string :Revenue
      t.text :Synopsis

      t.timestamps
    end
  end
end
