class CreateJobsTable < ActiveRecord::Migration[5.2]
  def change
    create_table :jobs do |t|
      t.string :Job_id

      t.text :Job_description
      t.string :Employment_type
      t.text :Responsibilities
      t.text :Requirements
      t.references :company
      t.timestamps
    end
  end
end
