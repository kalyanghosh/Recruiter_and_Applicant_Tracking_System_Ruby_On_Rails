class CreateApplications < ActiveRecord::Migration[5.2]
  def change
    create_table :applications do |t|
      t.string :application_id
      t.string :Linkedin_url
      t.string :Portfolio_url
      t.text :Additional_information
      t.string :Gender
      t.string :Race
      t.string :Veteran_status
      t.string :Disability_status
      t.timestamps
    end
  end
end
